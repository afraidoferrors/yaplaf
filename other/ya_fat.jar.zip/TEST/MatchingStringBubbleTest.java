package TEST;

import YAPLAF.LCSV.*;

public class MatchingStringBubbleTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		MatchingStringContainer test = new MatchingStringContainer();

		test.insert(0, 0, 2);
		test.insert(5, 5, 3);
		test.insert(10, 10, 2);
		test.insert(15, 15, 3);
		test.insert(100, 100, 5);
		test.insert(90, 90, 4);
		test.insert(50, 50, 5);
		test.insert(70, 70, 5);
		test.insert(20, 20, 4);
		test.insert(80, 80, 3);
		test.insert(30, 30, 3);
		System.out.println(test);

		System.out.println("\nSortieren\n");
		test.sort(0);

		System.out.println(test);

	}

}
