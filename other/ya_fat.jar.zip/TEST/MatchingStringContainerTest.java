package TEST;

import java.io.*;
import YAPLAF.LCSV.*;

public class MatchingStringContainerTest {

	static PrintStream out = System.out;

	public static void main(String[] args) {

		out.println("MatchingStringContainerTest");

		MatchingStringContainer conti = new MatchingStringContainer();
		//YAPLAF.LogWriter log = new YAPLAF.LogWriter();

		conti.insert(5,3,1);
		out.println(conti);
		conti.insert(4,6,2);
		out.println(conti);




	}

}
