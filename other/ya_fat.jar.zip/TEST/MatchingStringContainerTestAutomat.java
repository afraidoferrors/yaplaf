package TEST;

import YAPLAF.LCSV.*;

public class MatchingStringContainerTestAutomat {

	/**
	 * Idee:
	 *
	 * Es werden mit Math.Random Zufallszahlen und damit MatchingStrings erzeugt
	 *
	 * Anhand der schon gepr�ften Methode MatchingString.overlap wird ein neue L�nge des LCSVektors vorhergesagt
	 *
	 * @param args
	 */
	public static void main(String[] args) {

		int startmaximum = 5000;
		int laengemaximum = 500;
		int anzdurchlaeufe = 10000;

		int start0 = 0;
		int start1 = 0;
		int laenge = 0;
		int laengemax = 0;

		int LCSVektorLaenge = 0;

		MatchingString ms;
		MatchingString tempMS;
		MatchingStringContainer msc= new MatchingStringContainer();
		//java.util.LinkedList<YAPLAF.MatchingString> tempList0 = new java.util.LinkedList<YAPLAF.MatchingString>();
		//java.util.LinkedList<YAPLAF.MatchingString> tempList1 = new java.util.LinkedList<YAPLAF.MatchingString>();
		//java.util.LinkedList<YAPLAF.MatchingString> tempList = new java.util.LinkedList<YAPLAF.MatchingString>();
		String achtungString = "";


		int tempLaenge0;
		int tempLaenge1;

		int calcLaenge;

		boolean achtung = false;


		/*
		 * Zufallszahlen erzeugen:
		 * - start (2mal!) mit nextInt (gleichverteilt)
		 * - laenge mit nextGaussian (Normalverteilt um vor allem k�rzere MatchingStrings zu simulieren
		 *
		 */
		java.io.PrintStream out = System.out;

		java.util.Random r = new java.util.Random();

		for (int i = 0; i < anzdurchlaeufe; i++) {
			tempLaenge0 = 0;
			tempLaenge1 = 0;

			calcLaenge = 0;


			start0 = r.nextInt(startmaximum);
			start1 = r.nextInt(startmaximum);
			laenge = 1 + (int)(Math.abs(r.nextGaussian()) * (laengemaximum / 5)); //Annahme: Maximum liegt bei 5
			if (laenge > laengemax) {
				laengemax = laenge;
			}

			ms = new MatchingString(start0, start1, laenge);

			/*
			 * �berlappungen und neue L�nge des LCSVektor berechnen
			 *
			 */
			boolean eins;
			boolean zwei;

			msc.resetPointer();
			while(msc.hasNextMatchingString()) {
				tempMS = msc.nextMatchingString();
				/*
				 * �berlappungen berechnen (Wir gehen davon aus, dass overlap korrekt arbeitet!!!)
				 */
				if(eins = ms.overlap(tempMS, 0)) {
					tempLaenge0 += tempMS.getLength();
					//tempList0.add(tempMS);
				}
				if(zwei = ms.overlap(tempMS, 1)) {
					tempLaenge1 += tempMS.getLength();
					//tempList1.add(tempMS);
				}
				if(eins || zwei) {
					//tempList.add(tempMS);
					calcLaenge += tempMS.getLength();
				}
			}

			/*
			 * Bestimmen, ob eingef�gt werden soll oder nicht
			 * ACHTUNG!!!
			 * Dieser Teil ist komplett ident mit Original
			 */

			if(ms.getLength() > calcLaenge) {
			//if(ms.getLength() > tempLaenge0 && ms.getLength() > tempLaenge1) {
				/*
				 * Einf�gen simulieren...
				 * calcLaenge minus
				 * ms.length plus
				 */
				if(calcLaenge > ms.getLength()) {
					achtung = true;
					achtungString += i + " - mslength : " + ms.getLength() + " calcLaenge: " + calcLaenge + "\r\n";

				}
				LCSVektorLaenge = LCSVektorLaenge - calcLaenge + ms.getLength();
			}


			msc.insert(ms);

			out.println(i + "/" + anzdurchlaeufe + ": " + start0 + " " + start1 + " " + laenge);
			out.println("CalcLaenge: " + calcLaenge + " Vorhersage: " + msc.getMatchingStringSum() + " Berechnung: " + LCSVektorLaenge);

		}
		out.println(laengemax);
		if(achtung) out.println(achtungString); else out.println("ALLES OK");

	}

}
