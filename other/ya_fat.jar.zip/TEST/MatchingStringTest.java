package TEST;

import YAPLAF.LCSV.*;
import java.io.*;

public class MatchingStringTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		PrintStream out = System.out;

		String refString = "abcdefghijklmnopqrstuvwxyz";
		out.println("L�nge: " + refString.length());
		out.println(refString);
		out.println();

		int start0;
		int start1;
		int laenge;

		start0 = 5; //5; //3;
		start1 = 5; //3; //5;
		laenge = 10; //1; //5;
		MatchingString refMatch = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("Referenz");
		out.println(refString.substring(start0, start0 + laenge));
		out.println();


		start0 = 5;
		laenge = 10;
		MatchingString test = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("test");
		out.println(refString.substring(start0, start0 + laenge));
		out.println();

		if(refMatch.overlap(test, 0)) { //Fehler
			out.println("�berlappen");
		}
		else {
			out.println("NICHT �berlappen");
		}
		out.println();

		/*
		start0 = 0;
		start1 = 3;
		laenge = 4;
		MatchingString schnittmit1Ref = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("schneidet mit 1. Buchstaben");
		out.println(refString.substring(start0, start0 + laenge));
		if(refMatch.overlap(schnittmit1Ref, 0)) { //Fehler
			out.println("�berlappen");
		}
		else {
			out.println("NICHT �berlappen");
		}
		out.println();

		start0 = 0;
		start1 = 3;
		laenge = 13;
		MatchingString l�ngeralsRef = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("ist l�nger als Ref");
		out.println(refString.substring(start0, start0 + laenge));

		if(refMatch.overlap(l�ngeralsRef, 0)) out.println("�berlappen");
		else out.println("NICHT �berlappen");
		out.println();


		start0 = 4;
		start1 = 3;
		laenge = 4;
		MatchingString k�rzeralsRef = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("ist k�rzer als Ref");
		out.println(refString.substring(start0, start0 + laenge));

		if(refMatch.overlap(k�rzeralsRef, 0)) out.println("�berlappen");
		else out.println("NICHT �berlappen");
		out.println();


		start0 = 3;
		start1 = 3;
		laenge = 5;
		MatchingString istgleichRef = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("ist gleich Ref");
		out.println(refString.substring(start0, start0 + laenge));

		if(refMatch.overlap(istgleichRef, 0)) out.println("�berlappen");
		else out.println("NICHT �berlappen");
		out.println();


		start0 = 4;
		start1 = 6;
		laenge = 2;
		MatchingString istanders = new MatchingString(start0 ,start1, laenge); //Referenz
		out.println("ist anders");
		out.println(refString.substring(start0, start0 + laenge));

		if(refMatch.overlap(istanders, 0)) out.println("�berlappen");
		else out.println("NICHT �berlappen");
		out.println();
		*/

	}

}
