package TEST;

import YAPLAF.LCSV.*;
import java.io.*;

public class MatchingStringTestAutomat {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		PrintStream out = System.out;

		//Referenz String & Referenz MatchingString
		String refString = "abcdefghijklmnopqrstuvwxyz";
		out.println("L�nge: " + refString.length());
		out.println(refString);
		out.println();

		int start0;
		int start1 = 0;
		int laenge;

		int startRef0 = 2;
		int startRef1 = 0; //der ist egal
		int laengeRef = 4;
		MatchingString refMatch = new MatchingString(startRef0 ,startRef1, laengeRef); //Referenz
		out.print("Referenz: ");
		String temp = refString.substring(startRef0, startRef0 + laengeRef);
		out.println(refMatch + " - " + temp);
		out.println();

		int count = 0;
		boolean vorhersage;
		boolean tatsache;
		int fehler = 0;


		/*
		 * F�r jede M�glichkeit an Start und Endpunkt
		 * kleinster Startpunkt: 0, kleinster Endpunkt: 1 (L�nge 1)
		 * gr��ter Startpunk: 8, gr��ter Endpunkt: 9 (L�nge 1)
		 * --- eh klar... Endpunkt ist immer gr��er als Startpunkt
		 */

		int startpunktMax = 8;

		for (int i = 0; i < startpunktMax; i++) { //Startpunkte zwischen 0 und 8 setzen
			for (int j = i + 1; j < startpunktMax + 1; j++) { //Endpunkte zwischen 1 und 9
				/*
				 * F�r jedes Wertepaar erstelle MatchingString
				 */
				count++;
				start0 = i;
				laenge = j-i;
				MatchingString test = new MatchingString(start0, start1, laenge); //Referenz
				out.print("Fall " + count + ": ");
				out.println(test + " - " + refString.substring(start0, start0 + laenge) + " (" + refString.substring(startRef0, startRef0 + laengeRef) + ")");

				/*
				 * Erstelle die Vorhersage...
				 * mit Methode overlap
				 */
				out.print("Vorhersage: ");
				if(vorhersage = refMatch.overlap(test, 0)) { //Fehler
					out.println("�berlappen");
				}
				else {
					out.println("NICHT �berlappen");
				}

				/*
				 * Testprozedur
				 */
				tatsache = false;
				out.print("Tatsache: ");
				for (int z = i; z < j; z++) {
					//out.println("###"+temp.indexOf(refString.charAt(z)));
					if (temp.indexOf(refString.charAt(z)) != -1) {
						tatsache = true;
					}
				}
				if(tatsache) {
					out.println("�berlappen");
				}
				else {
					out.println("NICHT �berlappen");
				}

				if(vorhersage == tatsache) {
					out.println("OK");
				}
				else {
					out.println("FEHLER");
					fehler++;
				}


			}
		}
		out.println();
		out.println("Anzahl Fehler: " + fehler);
	}

}
