package TEST;

public class Haeufung {

	/**
	 * @param args
	 */
	public static void main(String[] args) throws Exception {
		int[] test1 = {0,0,0,0,1,1,1,0,1,0,1,1,1,1,0,0,0,0,0,1,1,1,1,1,1,0,1,1,0,0,0,1,1,0};
		int[] test2 = test1.clone();
		int[] ref = test1.clone();
		int zaehler1 = 0;
		int zaehler2 = 0;
		
		
		for(int i = 0; i < test1.length; i++) {
			if(test1[i] == 0) {
				test1[i] = --zaehler1;
			}
			else if(test1[i] == 1) {
				test1[i] = ++zaehler1;
			}
			else {
				throw new Exception("�HM!!!");
			}
		}
		
		for(int i = 0; i < test2.length; i++) {
			if(test2[i] == 0) {
				if(zaehler2 > 0) {
					test2[i] = --zaehler2;
				}
			}
			else if(test2[i] == 1) {
				test2[i] = ++zaehler2;
			}
			else {
				throw new Exception("�HM!!!");
			}
		}
		
		for(int i = 0; i < test2.length; i++) {
			System.out.println(ref[i] + " " + test1[i] + " " + test2[i]);
		}
			

	}

}
