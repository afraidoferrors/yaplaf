package YAPLAF.LCSV;

public interface LCSAlgorithmus {
	public int start() throws Exception;
	public void setSrc(String src);
	public void setDst(String src);
	public int getCount();
	public void setSchranke(int schranke);
}
