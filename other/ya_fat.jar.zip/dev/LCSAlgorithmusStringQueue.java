package YAPLAF.LCSV;

/**
 * Gedacht als Queue um YAPLAF MultiThreading zu machen
 *
 * @author Martin Weik
 *
 */


public class LCSAlgorithmusStringQueue {

	//Wie erfolgt die Ausgabe?
	//Nummerierung?

	public void put(String[] text) {
		//Einf�gen
	}
	public String[] get() {
		//Element �bergeben
		//synchronisieren!!!
		return new String[2];
	}


}
