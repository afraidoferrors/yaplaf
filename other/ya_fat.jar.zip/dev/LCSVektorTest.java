package TEST;

import YAPLAF.LCSV.*;
import YAPLAF.util.*;


public class LCSVektorTest {

	/**
	 * @param args
	 */
	@SuppressWarnings("deprecation")
	public static void main(String[] args) {

		LCSVektor lcs = new LCSVektor();
		lcs.setSchranke(7);

		String text1fn = "fall1text1kurz.txt";
		String text2fn = "fall1text2kurz.txt";

		text1fn = "fall2text1.txt";
		text2fn = "fall2text1.txt";

		// text1fn = "test1.txt";
		// text2fn = "test2.txt";

		text1fn = "fall1text1lang.txt";
		text2fn = "fall1text2lang.txt";

		text1fn = "test1231.txt";
		text2fn = "test1232.txt";
		/*
		 * text1fn = "help1.txt"; text2fn = "help2.txt";
		 */
		LogWriter out = new LogWriter();
		out.setLogFile("logLCSTest.txt");
		out.open();

		String text1 = "<p style=\"margin-bottom: 0cm;\">ad1: zu pr�fen ist �225a StGB :Es soll der Anschein erweckt werden das die Seite von einer anderen Person (Bank) betrieben wird... Neben dem Tatbildvorsatz ist idR auch der erweiterte Vorsatz, die falschen Daten im Rechtsverkehr zum Beweis eines Rechtsverh�ltnisses zu gebrauchen, gegeben. Objektiver Tatbestand � 225a erf�llt! des weiteren ist zu pr�fen � 126c StGB Missbrauch von Computerprogrammen oder Zugangsdaten IVM �146, �148a �126c Abs1 Z 2 StGB Demnach macht sich strafbar, wer sich einen Zugangscode mit dem Vorsatz verschafft, dass dieser zur Begehung eines betr�gerischen Datenverarbeitungsmissbrauchs (� 148a StGB) gebraucht werde. Da aus dem Sachverhalt nicht hervorgeht ob die geforderten Daten tats�chlich eingegeben wurden handelt es sich hier vorerst nur um einen Versuch laut �15Abs1und 2 .Dieser regelt den Tatbestand des Versuches und dessen Strafbarkeit. �15 IVM �126c und weitere ist zu bejahen. Ebenfalls denkbar w�re ein �15 Abs1,2 IVM � 108 Abs 1: Nach dem Wortlaut des � 108 ist strafbar, wer einen anderen �in seinen Rechten� dadurch sch�digt, dass er ihn oder einen Dritten durch T�uschung �ber Tatsachen zu einer Handlung, Duldung oder Unterlassung verleitet, die den Schaden herbeif�hrt .....w�re im vorliegenden Fall zutreffend. (ist aber umstritten!).Ad2 Verwertungs-Phase F�r die Verwertungs-Phase pr�fen wir die Strafbarkeit nach � 146 StGB (Betrug) und � 148a StGB (betr�gerischer Datenverarbeitungsmissbrauch). � 146 erfordert die T�uschung eines Menschen, � 148 hingegen die �T�uschung� einer Maschine. Eine Strafbarkeit kommt nach � 146 nur in Betracht, wenn der T�ter die in der Phishing-Phase erlangnten Daten gegen�ber einer nat�rlichen Person einsetzt (zB Phonebanking). In allen anderen F�llen m�sste mE eine Subsumtion unter � 148a erfolgen. Abschlie�en sei anzumerken das je nach der H�he des Schadens der � 147 Schwerer Betrug (Qualifikation des �146!) ebenfalls zu pr�fen sei.";
		String text2 = "1. Hinsichtlich der strafrechtlichen W�rdigung der Phishing-Attacken ist zwischen dem Auskundschaften der Zugangsdaten und/oder TANs (eigentliches Phishing) sowie dem sp�teren Benutzen dieser Daten um&nbsp; etwa Zugriff auf das fremde Konto zu erlangen zu differenzieren. Das eigentliche Phishen wird vom Tatbestand des � 126c StGB (Missbrauch von Computerprogrammen oder Zugangsdaten) in ausreichendem Ma�e erfasst. Demnach macht sich strafbar, wer sich einen Zugangscode mit dem Vorsatz verschafft, dass dieser zur Begehung eines betr�gerischen Datenverarbeitungsmissbrauchs (� 148a StGB) gebraucht werde. Entscheidend ist einzig und allein, dass der T�ter mit dem Vorsatz handelt, die Daten sp�ter gewinnbringend zu verwerten. Ist der T�ter mit seiner Phishing-Attacke erfolgreich unterf�llt jede unbefugte Abbuchung im Namen des Opfers unter den bereits erw�hnten Tatbestand des � 148a StGB. Allerdings wird die Vorbereitung eines Diebstahls gem�� � 126c StGB nicht erfasst. Ein weiterer in Betracht kommender Straftatbestand ist � 108 StGB. Nach dem Wortlaut des �108 ist strafbar, wer einen anderen in seinen Rechten dadurch sch�digt, dass er ihn oder einen Dritten durch T�uschung �ber Tatsachen zu einer Handlung, Duldung oder Unterlassung verleitet, die den Schaden herbeif�hrt. Eine Strafbarkeit nach � 225a StGB ist daher i.d.R. zu bejahen. Das in der Phishing-Phase erfolgende sich Verschaffen bzw. das nachfolgende Besitzen erf�llt daher den Tatbestand. Beurteilt man hingegen die Verwertungsphase nur nach � 146, so hat der T�ter in der Phishing-Phase nur einen Vorsatz � 146 jedoch nicht � 148a zu begehen. F�r die Phishing-Phase kann daher zusammenfassend gesagt werden, dass i.d.R. eine Strafbarkeit nach � 225a, � 119 oder � 119a eintritt. <br />2. F�r die Verwertungs-Phase kommt nur eine Strafbarkeit nach � 146 StGB (Betrug) und �148a StGB (betr�gerischer Datenverarbeitungsmissbrauch) in Betracht. Grunds�tzlich erfordert � 146 die T�uschung eines Menschen, � 148 hingegen die T�uschung einer Maschine. Meines Erachtens kommt eine Strafbarkeit nach � 146 daher nur in Betracht, wenn der T�ter die in der Phishing-Phase erlangten Daten gegen�ber einer nat�rlichen Person einsetzt. In allen anderen F�llen m�sste eine Subsumtion unter � 148a erfolgen. <br />";

//		try {
//			BufferedReader t1 = new BufferedReader(new FileReader(text1fn));
//			BufferedReader t2 = new BufferedReader(new FileReader(text2fn));
//
//			String temp;
//
//			while ((temp = t1.readLine()) != null) {
//				text1 += temp;
//			}
//			while ((temp = t2.readLine()) != null) {
//				text2 += temp;
//			}
//		} catch (Exception e) {
//			out.println("Eingabedatei nicht gefunden...");
//			System.exit(0);
//		}

		out.println("######### LCSVektorTest #########");
		out.println("Vergleiche Datei \"" + text1fn + "\" mit Datei \""
				+ text2fn + "\".");
		out.println();

		out.println("##### Inhalt von \"" + text1fn + "\"#####");
		out.println("## Ungek�rzt BEGINN (L�nge " + text1.length() + ") ##");
		out.println(text1);
		out.println("## Ungek�rzt ENDE ##");
		out.println();

		text1 = Abgabe.itrim(text1);

		out.println("## Gek�rzt BEGINN (L�nge " + text1.length() + ") ##");
		out.println(text1);
		out.println("## Gek�rzt ENDE ##");
		out.println();
		out.println();

		out.println("##### Inhalt von \"" + text2fn + "\"#####");
		out.println("## Ungek�rzt BEGINN (L�nge " + text2.length() + ") ##");
		out.println(text2);
		out.println("## Ungek�rzt ENDE ##");
		out.println();

		text2 = Abgabe.itrim(text2);

		out.println("## Gek�rzt BEGINN (L�nge " + text2.length() + ") ##");
		out.println(text2);
		out.println("## Gek�rzt ENDE ##");
		out.println();

		lcs.setDst(text1);
		lcs.setSrc(text2);

		int ergebnis = 0;

		try {
			ergebnis = lcs.start();
			// ergebnis = lcs.getMatchingStringCount();
		} catch (Exception e) {
		}

		out.println("#### Ergebnis: " + ergebnis + " ###");
		out.println("Das sind " + ((ergebnis * 100) / text1.length()) + " von Text 1.");
		out.println("Das sind " + ((ergebnis * 100) / text2.length()) + " von Text 2.");
		out.println();
		// out.println("# Ausgabe der MatchingStrings # ");
		// out.println(lcs);

		// out.println("Sortiere");

		// out.println(lcs.getHistory());

		// lcs.testAnalyzedParts();

		java.util.LinkedList<LCSVektorAnalyzedPartsMessage> liste = lcs
				.analyzeParts();

		LCSVektorAnalyzedPartsMessage tempMess;

		tempMess = liste.poll();
		out.println(tempMess);

		tempMess = liste.poll();
		out.println(tempMess);

//		lcs.analyzePartsNew();
//
		lcs.sort(0);
		MatchingStringContainer conti = lcs.getContainer();

		for (MatchingString ms : conti) {
			out.println(ms.start[0] + " " + ms.end[0] + " " + ms.length);
		}

		out.println(lcs);

//		int[] matchStrings = new int[text2.length()];
//		int[] matchStringsAn = new int[text2.length()];
//
//		for (int i = 0; i < matchStrings.length; i++) {
//			matchStrings[i] = 0;
//		}
//
//		for (MatchingString ms : conti) {
//			System.out.println(ms);
//			for (int i = ms.start[0]; i < ms.end[0]; i++) {
//				matchStrings[i] = 1;
//			}
//		}
//		for (int i = 0; i < matchStrings.length; i++) {
//			System.out.print(matchStrings[i]);
//		}
//		System.out.println();
//		int zaehler = 0;
//		int max = 0;
//		int maxPos = 0;
//		for (int i = 0; i < matchStrings.length; i++) {
//
//			if (matchStrings[i] == 0) {
//				if (zaehler > 0) {
//					matchStringsAn[i] = --zaehler;
//				}
//			} else if (matchStrings[i] == 1) {
//				matchStringsAn[i] = ++zaehler;
//				if(zaehler > max) {
//					max = zaehler;
//					maxPos = i;
//				}
//			} else {
//
//			}
//			System.out.println(i + " " + matchStrings[i] + " " + matchStringsAn[i]);
//		}
//
//		System.out.println(max + ": " + maxPos);
		out.closeThis();

	}

}
