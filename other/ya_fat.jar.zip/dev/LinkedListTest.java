package TEST;

public class LinkedListTest {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		java.util.LinkedList <String>liste = new java.util.LinkedList<String>();

		liste.add("Text1");
		liste.add("Text2");
		liste.add("Text3");

		System.out.println(liste.getFirst());
		System.out.println(liste.getFirst());
		System.out.println(liste.getFirst());

		System.out.println();
		System.out.println(liste.poll());
		System.out.println(liste.poll());
		System.out.println(liste.poll());

	}

}
